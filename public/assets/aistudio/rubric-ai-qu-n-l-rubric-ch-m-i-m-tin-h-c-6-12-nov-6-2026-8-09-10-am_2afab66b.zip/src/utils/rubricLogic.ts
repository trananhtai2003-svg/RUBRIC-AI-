import { AnalysisResult, Criterion, Student } from '../types/rubric';

export function normText(v: string | null | undefined): string {
  return String(v || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

export function fmt(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  return Number(n).toFixed(2).replace('.', ',');
}

export function scoreLevels(
  levels: (number | null | undefined)[] | null | undefined,
  weights: number[]
): number | null {
  if (!levels || levels.length !== 4) return null;
  if (levels.some((x) => x === null || x === undefined || !Number.isFinite(Number(x)) || Number(x) < 1 || Number(x) > 4)) {
    return null;
  }
  return levels.reduce<number>((acc, level, i) => {
    const l = Number(level);
    const w = weights[i] ?? 25;
    return acc + (l / 4) * (w / 100) * 10;
  }, 0);
}

export function rank(score: number | null | undefined): {
  label: string;
  badgeClass: string;
  badgeBg: string;
  badgeText: string;
} {
  if (score === null || score === undefined || !Number.isFinite(score)) {
    return {
      label: 'Chưa chấm',
      badgeClass: 'none',
      badgeBg: 'bg-slate-100 dark:bg-slate-800',
      badgeText: 'text-slate-600 dark:text-slate-400',
    };
  }
  if (score >= 8.5) {
    return {
      label: 'Tốt',
      badgeClass: 'good',
      badgeBg: 'bg-emerald-100 dark:bg-emerald-950/50',
      badgeText: 'text-emerald-800 dark:text-emerald-300',
    };
  }
  if (score >= 7.0) {
    return {
      label: 'Khá',
      badgeClass: 'mid',
      badgeBg: 'bg-amber-100 dark:bg-amber-950/50',
      badgeText: 'text-amber-800 dark:text-amber-300',
    };
  }
  if (score >= 5.0) {
    return {
      label: 'Đạt',
      badgeClass: 'ok',
      badgeBg: 'bg-sky-100 dark:bg-sky-950/50',
      badgeText: 'text-sky-800 dark:text-sky-300',
    };
  }
  return {
    label: 'Chưa đạt',
    badgeClass: 'low',
    badgeBg: 'bg-rose-100 dark:bg-rose-950/50',
    badgeText: 'text-rose-800 dark:text-rose-300',
  };
}

export function parseCSV(text: string): Student[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  const clean = text.replace(/^\uFEFF/, '');

  for (let i = 0; i < clean.length; i++) {
    const c = clean[i];
    const next = clean[i + 1];

    if (c === '"' && quoted && next === '"') {
      field += '"';
      i++;
    } else if (c === '"') {
      quoted = !quoted;
    } else if ((c === ',' || c === ';' || c === '\t') && !quoted) {
      row.push(field.trim());
      field = '';
    } else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && next === '\n') i++;
      row.push(field.trim());
      if (row.some((x) => x !== '')) rows.push(row);
      row = [];
      field = '';
    } else {
      field += c;
    }
  }
  row.push(field.trim());
  if (row.some((x) => x !== '')) rows.push(row);

  if (rows.length < 2) return [];

  const headers = rows.shift()!.map((h) => normText(h));
  const find = (names: string[]) => headers.findIndex((h) => names.includes(h));

  const ix = {
    code: find(['mahs', 'mahocsinh', 'studentid', 'code', 'sobaodanh', 'id']),
    name: find(['hoten', 'tenhocsinh', 'fullname', 'name', 'hovaten']),
    grade: find(['khoi', 'khoilop', 'grade', 'caplop']),
    cls: find(['lop', 'malop', 'class', 'classroom']),
  };

  if (ix.name < 0 || ix.cls < 0) {
    throw new Error('Không nhận diện được cột Họ tên và Lớp trong tệp CSV.');
  }

  return rows
    .map((r, i) => {
      const cls = (r[ix.cls] || '').trim();
      const gradeRaw = ix.grade >= 0 ? r[ix.grade] : '';
      const gm = String(gradeRaw || '').match(/\d+/);
      const cm = cls.match(/\d+/);
      const grade = gm ? Number(gm[0]) : cm ? Number(cm[0]) : 6;
      const code = (ix.code >= 0 ? r[ix.code] : '').trim() || `HS${String(i + 1).padStart(4, '0')}`;
      const name = (r[ix.name] || '').trim();

      return {
        code,
        name,
        grade,
        cls,
        levels: null,
        file: '',
        demo: false,
      };
    })
    .filter((s) => s.name && s.cls);
}

export function matchSubmissionFilename(filename: string, studentCode: string): boolean {
  if (!filename || !studentCode) return false;
  const stem = filename.replace(/\.[^.]+$/, '');
  const nFile = normText(stem);
  const nCode = normText(studentCode);
  return nFile.includes(nCode);
}

export async function unzipTextFile(file: File, wanted: string): Promise<string> {
  const buf = await file.arrayBuffer();
  const dv = new DataView(buf);
  let eocd = -1;

  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) {
      eocd = i;
      break;
    }
  }

  if (eocd < 0) {
    throw new Error('Không tìm thấy cấu trúc ZIP trong tệp DOCX.');
  }

  const count = dv.getUint16(eocd + 10, true);
  const cdOff = dv.getUint32(eocd + 16, true);
  let pos = cdOff;

  for (let i = 0; i < count; i++) {
    if (dv.getUint32(pos, true) !== 0x02014b50) break;
    const method = dv.getUint16(pos + 10, true);
    const csize = dv.getUint32(pos + 20, true);
    const nlen = dv.getUint16(pos + 28, true);
    const elen = dv.getUint16(pos + 30, true);
    const clen = dv.getUint16(pos + 32, true);
    const local = dv.getUint32(pos + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(buf, pos + 46, nlen));

    if (name === wanted) {
      const ln = dv.getUint16(local + 26, true);
      const le = dv.getUint16(local + 28, true);
      const start = local + 30 + ln + le;
      const compressed = buf.slice(start, start + csize);

      let raw: ArrayBuffer;
      if (method === 0) {
        raw = compressed;
      } else if (method === 8) {
        if (!('DecompressionStream' in window)) {
          throw new Error('Trình duyệt chưa hỗ trợ giải nén DecompressionStream. Vui lòng cập nhật Chrome/Edge.');
        }
        const ds = new DecompressionStream('deflate-raw');
        raw = await new Response(new Blob([compressed]).stream().pipeThrough(ds)).arrayBuffer();
      } else {
        throw new Error('Định dạng nén DOCX không được hỗ trợ.');
      }
      return new TextDecoder().decode(raw);
    }
    pos += 46 + nlen + elen + clen;
  }
  throw new Error(`Không tìm thấy "${wanted}" trong tệp.`);
}

export function xmlText(xml: string): string {
  const doc = new DOMParser().parseFromString(xml, 'application/xml');
  return Array.from(doc.getElementsByTagNameNS('*', 't'))
    .map((n) => n.textContent || '')
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function inspectSubmission(file: File): Promise<AnalysisResult> {
  const ext = (file.name.split('.').pop() || '').toLowerCase();

  if (ext === 'docx') {
    try {
      const xml = await unzipTextFile(file, 'word/document.xml');
      const doc = new DOMParser().parseFromString(xml, 'application/xml');
      const tables = Array.from(doc.getElementsByTagNameNS('*', 'tbl'));
      const tableInfo = tables.map((t) => {
        const rows = Array.from(t.getElementsByTagNameNS('*', 'tr'));
        return {
          rows: rows.length,
          cols: Math.max(0, ...rows.map((r) => r.getElementsByTagNameNS('*', 'tc').length)),
          text: Array.from(t.getElementsByTagNameNS('*', 't'))
            .map((n) => n.textContent || '')
            .join(' ')
            .trim(),
        };
      });

      const text = xmlText(xml);
      const rowCount = tableInfo.reduce((a, t) => a + t.rows, 0);
      const colMax = Math.max(0, ...tableInfo.map((t) => t.cols));
      const hasWeekDays =
        /thu hai/i.test(normText(text)) &&
        /thu ba/i.test(normText(text)) &&
        /thu tu/i.test(normText(text));
      const nonempty = text.length >= 120;
      const tableOk = tables.length > 0 && rowCount >= 5 && colMax >= 3;
      const contentOk = nonempty && hasWeekDays;
      const formatOk = tableOk && colMax >= 4;

      const levels = [
        tableOk ? (rowCount >= 6 && colMax >= 4 ? 4 : 3) : tables.length ? 2 : 1,
        contentOk ? (text.length > 500 ? 4 : 3) : nonempty ? 2 : 1,
        formatOk ? 3 : tableOk ? 2 : 1,
        nonempty && tableOk ? 3 : 1,
      ];

      return {
        kind: 'DOCX đọc được',
        textLength: text.length,
        tables: tableInfo,
        summary: `Đọc được nội dung DOCX; phát hiện ${tables.length} bảng, ${rowCount} hàng tổng, tối đa ${colMax} cột.`,
        levels,
        evidence: [
          `Phát hiện ${tables.length} bảng; ${rowCount} hàng, tối đa ${colMax} cột.`,
          `Văn bản trích xuất ${text.length} ký tự; ${hasWeekDays ? 'có các ngày trong tuần được phát hiện' : 'chưa phát hiện đủ tên các ngày trong tuần'}.`,
          `Kiểm tra cấu trúc bảng: ${formatOk ? 'có bảng từ 4 cột, ít nhất 5 hàng' : 'chưa đạt điều kiện bảng 4 cột và ít nhất 5 hàng'}.`,
          `Đã trích xuất nội dung; giáo viên cần kiểm tra trực quan kiểu chữ, căn chỉnh và độ dễ đọc.`,
        ],
        rawText: text.slice(0, 1200),
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        kind: 'DOCX lỗi phân tích',
        textLength: 0,
        tables: [],
        summary: `Không thể đọc nội dung DOCX: ${msg}`,
        levels: null,
        evidence: [`Lỗi phân tích: ${msg}`],
        rawText: '',
      };
    }
  }

  if (['txt', 'csv', 'py'].includes(ext)) {
    try {
      const text = await file.text();
      const lines = text.split(/\r?\n/).filter((x) => x.trim());
      const levels = [
        text.length > 250 ? 3 : text.length > 50 ? 2 : 1,
        lines.length >= 5 ? 3 : lines.length >= 2 ? 2 : 1,
        lines.some((x) => /[;,\t]/.test(x)) ? 3 : 2,
        lines.length >= 8 ? 3 : lines.length ? 2 : 1,
      ];

      return {
        kind: `${ext.toUpperCase()} đọc được`,
        textLength: text.length,
        tables: [],
        summary: `Đọc được văn bản ${text.length} ký tự, ${lines.length} dòng có nội dung.`,
        levels,
        evidence: [
          `Tệp có ${lines.length} dòng không rỗng.`,
          `Độ dài nội dung ${text.length} ký tự.`,
          lines.some((x) => /[;,\t]/.test(x))
            ? 'Có ký tự phân tách dạng bảng/cột.'
            : 'Chưa thấy ký tự phân tách dạng bảng rõ ràng.',
          'Đã đọc nội dung văn bản; tiêu chí định dạng trực quan cần giáo viên đánh giá.',
        ],
        rawText: text.slice(0, 1200),
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        kind: `${ext.toUpperCase()} lỗi`,
        textLength: 0,
        tables: [],
        summary: `Lỗi đọc tệp: ${msg}`,
        levels: null,
        evidence: [`Lỗi: ${msg}`],
        rawText: '',
      };
    }
  }

  return {
    kind: 'Chưa có bộ phân tích',
    textLength: 0,
    tables: [],
    summary: `Chưa có bộ đọc nội dung tự động cho .${ext || 'không rõ định dạng'}. Không tự gán điểm để tránh tạo kết quả sai.`,
    levels: null,
    evidence: ['Định dạng tệp cần giáo viên mở trực tiếp để đối chiếu Rubric.'],
    rawText: '',
  };
}

export function generateDocxBlob(
  title: string,
  criteriaOrContent: Criterion[] | string,
  grade: number = 6,
  lesson: number = 1,
  taskContent?: string
): Blob {
  const esc = (s: unknown) =>
    String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

  let rows = '';
  let bodyContent = '';

  if (typeof criteriaOrContent === 'string') {
    bodyContent = `<div style="font-family:Arial,sans-serif;white-space:pre-wrap;font-size:11pt;line-height:1.5;">${esc(
      criteriaOrContent
    )}</div>`;
  } else {
    rows = criteriaOrContent
      .map(
        (x, i) => `
      <tr>
        <td style="text-align:center;">${i + 1}</td>
        <td><b>${esc(x[0])}</b></td>
        <td style="text-align:center;"><b>${esc(x[1])}%</b></td>
        <td>${esc(x[2][0])}</td>
        <td>${esc(x[2][1])}</td>
        <td>${esc(x[2][2])}</td>
        <td>${esc(x[2][3])}</td>
      </tr>`
      )
      .join('');

    bodyContent = taskContent
      ? `<div style="font-family:Arial,sans-serif;white-space:pre-wrap;font-size:11pt;line-height:1.5;">${esc(
          taskContent
        )}</div>`
      : `<ol>
          <li>Mở Microsoft Word và tạo văn bản có tiêu đề <b>THỜI KHÓA BIỂU TRỰC TUẦN</b>, căn giữa, in đậm.</li>
          <li>Tạo bảng gồm <b>4 cột</b>: Thứ/ngày, Buổi sáng, Buổi chiều, Ghi chú; có hàng tiêu đề và ít nhất <b>5 hàng dữ liệu</b> từ Thứ Hai đến Thứ Sáu.</li>
          <li>Điền nội dung hoạt động học tập phù hợp vào bảng; không để trống toàn bộ các ô dữ liệu.</li>
          <li>Định dạng hàng tiêu đề nổi bật; căn chỉnh văn bản, điều chỉnh độ rộng cột để dễ đọc; áp dụng đường viền bảng.</li>
          <li>Thêm dòng họ tên và lớp ở đầu hoặc cuối tài liệu; rà soát lỗi chính tả và lưu tệp .docx.</li>
        </ol>`;
  }

  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Đề thực hành - ${esc(title)}</title>
  <style>
    body { font-family: 'Times New Roman', Arial, sans-serif; font-size: 12pt; line-height: 1.45; color: #111; margin: 20px; }
    h1, h2 { text-align: center; margin: 6px 0; }
    h1 { font-size: 16pt; font-weight: bold; }
    h2 { font-size: 14pt; font-weight: bold; color: #174e90; }
    h3 { font-size: 13pt; margin-top: 18px; margin-bottom: 6px; border-bottom: 1px solid #999; padding-bottom: 4px; }
    table { border-collapse: collapse; width: 100%; margin-top: 10px; font-size: 10.5pt; }
    td, th { border: 1px solid #333; padding: 6px 8px; vertical-align: top; }
    th { background-color: #edf4fb; font-weight: bold; text-align: center; }
  </style>
</head>
<body>
  <h1>ĐỀ KIỂM TRA / BÀI THỰC HÀNH TIN HỌC</h1>
  <h2>Khối ${grade} – ${esc(title)}</h2>
  <p><b>Họ và tên học sinh:</b> .................................................... <b>Lớp:</b> ................</p>
  <p><b>Mã học sinh:</b> .................................... <b>Ngày thực hiện:</b> ....../....../..........</p>
  
  <h3>I. Yêu cầu & Nhiệm vụ thực hành</h3>
  ${bodyContent}

  <h3>II. Rubric đánh giá năng lực thực hành</h3>
  <p><i>Thang mức: 1 – Chưa đạt; 2 – Đạt một phần; 3 – Đạt yêu cầu; 4 – Vượt yêu cầu.</i></p>
  <table>
    <thead>
      <tr>
        <th style="width: 35px;">STT</th>
        <th style="width: 140px;">Tiêu chí</th>
        <th style="width: 60px;">Trọng số</th>
        <th>Mức 1 (Chưa đạt)</th>
        <th>Mức 2 (Đạt một phần)</th>
        <th>Mức 3 (Đạt yêu cầu)</th>
        <th>Mức 4 (Vượt yêu cầu)</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>

  <h3>III. Nhận xét & Đánh giá của giáo viên</h3>
  <p>Điểm mạnh: ............................................................................................................................</p>
  <p>Nội dung cần hoàn thiện: ............................................................................................................</p>
  <p>Hướng dẫn tiếp theo: ................................................................................................................</p>
  <table style="border: none; margin-top: 30px; width: 100%;">
    <tr style="border: none;">
      <td style="border: none; width: 50%;"></td>
      <td style="border: none; text-align: center; width: 50%;">
        <i>Ngày ...... tháng ...... năm 202...</i><br>
        <b>Giáo viên ra đề / chấm điểm</b><br>
        <i>(Ký và ghi rõ họ tên)</i>
      </td>
    </tr>
  </table>
</body>
</html>`;

  return new Blob(['\ufeff' + html], { type: 'application/msword;charset=utf-8;' });
}

export function downloadBlob(blob: Blob, filename: string): void {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  }, 1000);
}
