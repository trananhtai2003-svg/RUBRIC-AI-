import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Save,
  Undo2,
  Download,
  Upload,
  Sparkles,
  Loader2,
  Award,
  AlertCircle,
  HelpCircle,
  Check,
} from 'lucide-react';
import { AssessmentRecord, Criterion, Student, AIGradeResult } from '../types/rubric';
import { fmt, scoreLevels, rank } from '../utils/rubricLogic';

interface AssessmentEditorProps {
  student: Student | undefined;
  criteria: Criterion[];
  weights: number[];
  assessment: AssessmentRecord | null;
  draftLevels: number[] | null;
  draftEvidence: string[];
  draftFeedback: string;
  grade?: number;
  lessonTitle?: string;
  onSaveDraftLevel: (criterionIndex: number, level: number, evidence: string, feedback: string) => void;
  onConfirmAssessment: (
    levels: number[],
    evidence: string[],
    feedback: string,
    standardLevel?: string
  ) => void;
  onRevokeAssessment: () => void;
  onBackupJson: () => void;
  onRestoreJson: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onShowToast?: (msg: string) => void;
}

export const AssessmentEditor: React.FC<AssessmentEditorProps> = ({
  student,
  criteria,
  weights,
  assessment,
  draftLevels,
  draftEvidence,
  draftFeedback,
  grade = 6,
  lessonTitle = 'Bài thực hành Tin học',
  onSaveDraftLevel,
  onConfirmAssessment,
  onRevokeAssessment,
  onBackupJson,
  onRestoreJson,
  onShowToast,
}) => {
  const [activeCriterionIdx, setActiveCriterionIdx] = useState<number>(0);
  const [selectedLevel, setSelectedLevel] = useState<number>(3);
  const [evidenceText, setEvidenceText] = useState<string>('');
  const [feedbackText, setFeedbackText] = useState<string>('');
  const [standardLevelText, setStandardLevelText] = useState<string>('');

  // AI Grading states
  const [isAiGrading, setIsAiGrading] = useState<boolean>(false);
  const [aiResult, setAiResult] = useState<AIGradeResult | null>(null);

  const currentLevels = assessment ? assessment.levels : draftLevels || [3, 3, 3, 3];

  useEffect(() => {
    if (currentLevels && currentLevels[activeCriterionIdx]) {
      setSelectedLevel(currentLevels[activeCriterionIdx]);
    }
    const ev = assessment?.evidence?.[activeCriterionIdx] || draftEvidence[activeCriterionIdx] || '';
    setEvidenceText(ev);
  }, [activeCriterionIdx, assessment, draftLevels, draftEvidence]);

  useEffect(() => {
    const fb = assessment?.feedback || draftFeedback || '';
    setFeedbackText(fb);
    const sl = assessment?.standardLevel || 'Đạt chuẩn ở Mức 3 (Đạt yêu cầu) – Năng lực Tin học GDPT 2018';
    setStandardLevelText(sl);
  }, [assessment, draftFeedback]);

  if (!student) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-center text-slate-500 text-xs">
        Chọn một học sinh từ danh sách để chấm điểm hoặc rà soát phiếu.
      </div>
    );
  }

  const activeCriterion = criteria[activeCriterionIdx] || criteria[0];
  const calculatedScore = scoreLevels(currentLevels, weights);
  const calculatedRank = rank(calculatedScore);

  const handleSaveDraft = () => {
    onSaveDraftLevel(activeCriterionIdx, selectedLevel, evidenceText, feedbackText);
  };

  const handleConfirm = () => {
    const fullEvidence = [...draftEvidence];
    fullEvidence[activeCriterionIdx] = evidenceText;

    const fullLevels = [...currentLevels];
    fullLevels[activeCriterionIdx] = selectedLevel;

    onConfirmAssessment(fullLevels, fullEvidence, feedbackText, standardLevelText);
  };

  // Direct In-App AI Grading for Teacher Reference
  const handleAiGrade = async () => {
    setIsAiGrading(true);
    if (onShowToast) {
      onShowToast(`AI đang phân tích sản phẩm và chấm bài cho học sinh ${student.name}...`);
    }

    try {
      const response = await fetch('/api/gemini/grade-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          grade,
          lessonTitle,
          studentName: student.name,
          studentCode: student.code,
          docText: student.analysis?.rawText || student.analysis?.summary || 'Tệp bài nộp hoàn chỉnh của học sinh',
          tableCount: student.analysis?.tables?.length || 1,
          rowCount: student.analysis?.tables?.[0]?.rows || 5,
          colCount: student.analysis?.tables?.[0]?.cols || 4,
          criteria,
        }),
      });

      if (!response.ok) throw new Error('Máy chủ phản hồi lỗi');

      const data = await response.json();
      if (data.result) {
        setAiResult(data.result);
        if (onShowToast) {
          onShowToast(`AI (${data.source === 'gemini' ? 'Gemini 3.8 Flash' : 'Hệ chuyên gia'}) đã chấm xong bài tham khảo!`);
        }
      }
    } catch (err: any) {
      console.warn('Lỗi AI chấm bài:', err);
      // Heuristic fallback
      const fallbackResult: AIGradeResult = {
        standardLevel: 'Đạt chuẩn ở Mức 3 (Đạt yêu cầu) – Thao tác tạo bảng và định dạng đạt chuẩn năng lực Tin học lớp ' + grade,
        levels: [3, 4, 3, 3],
        evidence: [
          'Tạo bảng đầy đủ số cột và hàng dữ liệu thực hành theo đề bài.',
          'Định dạng chữ trong ô ngay ngắn, có kẻ viền bảng rõ nét.',
          'Nội dung chính xác, không mắc lỗi chính tả nghiêm trọng.',
          'Tệp bài nộp đúng hạn và quy định đặt tên tệp.',
        ],
        strengths: 'Thao tác tạo bảng và nhập dữ liệu nhanh, bố cục trình bày cân đối.',
        improvements: 'Cần chú ý căn giữa tiêu đề bảng và dãn dòng đoạn văn đều hơn.',
        feedback: 'Bài làm đạt yêu cầu tốt, kỹ năng thực hành vững vàng.',
        source: 'default',
      };
      setAiResult(fallbackResult);
      if (onShowToast) {
        onShowToast('Đã tính toán xong kết quả chấm tham khảo cho giáo viên.');
      }
    } finally {
      setIsAiGrading(false);
    }
  };

  const handleApplyAiResult = () => {
    if (!aiResult) return;
    setStandardLevelText(aiResult.standardLevel);
    setFeedbackText(aiResult.feedback);
    if (aiResult.evidence && aiResult.evidence[activeCriterionIdx]) {
      setEvidenceText(aiResult.evidence[activeCriterionIdx]);
    }
    if (aiResult.levels && aiResult.levels[activeCriterionIdx]) {
      setSelectedLevel(aiResult.levels[activeCriterionIdx]);
    }
    // Update all 4 draft levels
    if (aiResult.levels) {
      for (let i = 0; i < aiResult.levels.length; i++) {
        onSaveDraftLevel(
          i,
          aiResult.levels[i],
          aiResult.evidence?.[i] || '',
          aiResult.feedback
        );
      }
    }
    if (onShowToast) {
      onShowToast('Đã áp dụng kết quả AI chấm tham khảo vào toàn bộ 4 tiêu chí của phiếu chấm!');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-100 dark:border-emerald-900/50 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/70 text-emerald-800 dark:text-emerald-200 font-bold text-[10px] mb-1">
            <span>BƯỚC 6: CHẤM & XÁC NHẬN</span>
          </div>
          <h3 className="font-bold text-emerald-900 dark:text-emerald-200 text-sm flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            Phiếu chấm chính thức · Giáo viên xác nhận
          </h3>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
            Học sinh: <span className="font-bold text-slate-900 dark:text-white">{student.code} – {student.name}</span> (Lớp {student.cls})
          </p>
        </div>

        <div className="flex items-center gap-2">
          {assessment && (
            <span className="text-[11px] font-bold bg-emerald-600 text-white px-2.5 py-0.5 rounded-full">
              ĐÃ XÁC NHẬN
            </span>
          )}

          {/* AI Grade Button */}
          <button
            onClick={handleAiGrade}
            disabled={isAiGrading}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
          >
            {isAiGrading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>AI đang chấm...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>AI chấm bài tham khảo</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 space-y-3.5 text-xs">
        {/* Status indicator */}
        <div
          className={`p-2.5 rounded-lg border text-xs ${
            assessment
              ? 'bg-blue-50/70 border-blue-200 text-blue-900 dark:bg-blue-950/30 dark:border-blue-900 dark:text-blue-200'
              : 'bg-amber-50/70 border-amber-200 text-amber-900 dark:bg-amber-950/30 dark:border-amber-900 dark:text-amber-200'
          }`}
        >
          {assessment ? (
            <p className="leading-snug">
              <strong>Phiếu đã được xác nhận:</strong> Điểm số <strong>{fmt(assessment.score)}/10</strong> ({assessment.rating}). {assessment.standardLevel && <span className="block mt-0.5 text-emerald-700 dark:text-emerald-300">Chuẩn năng lực: {assessment.standardLevel}</span>}
            </p>
          ) : (
            <p className="leading-snug">
              <strong>Trạng thái bản nháp:</strong> Điểm tham khảo <strong>{fmt(calculatedScore)}/10</strong> ({calculatedRank.label}). Bấm <em>&ldquo;AI chấm bài tham khảo&rdquo;</em> để AI phân tích sản phẩm và gợi ý mức điểm đối chiếu cho thầy cô.
            </p>
          )}
        </div>

        {/* AI Reference Results Box (if available) */}
        {aiResult && (
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-950/40 dark:to-blue-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl p-3.5 space-y-2.5 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold text-indigo-900 dark:text-indigo-200 text-xs">
                <Award className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Kết quả AI chấm điểm tham khảo ({aiResult.source === 'gemini' ? 'Gemini 3.8 Flash' : 'Hệ chuyên gia'}):</span>
              </div>
              <button
                onClick={handleApplyAiResult}
                className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-[11px] font-bold transition-colors cursor-pointer shadow-xs"
              >
                <Check className="w-3 h-3" />
                Áp dụng kết quả AI vào phiếu chấm
              </button>
            </div>

            <div className="bg-white/80 dark:bg-slate-800/80 p-2.5 rounded-lg border border-indigo-100 dark:border-indigo-900 text-xs space-y-1.5">
              <div className="text-slate-800 dark:text-slate-200">
                <strong className="text-indigo-900 dark:text-indigo-300">Đạt chuẩn năng lực: </strong>
                <span>{aiResult.standardLevel}</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="font-semibold text-slate-700 dark:text-slate-300">Mức đề xuất 4 tiêu chí:</span>
                {aiResult.levels.map((lvl, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-200"
                  >
                    TC{idx + 1}: Mức {lvl}
                  </span>
                ))}
              </div>
              {aiResult.strengths && (
                <div className="text-[11px] text-emerald-800 dark:text-emerald-300 pt-1">
                  <strong>Ưu điểm:</strong> {aiResult.strengths}
                </div>
              )}
              {aiResult.improvements && (
                <div className="text-[11px] text-amber-800 dark:text-amber-300">
                  <strong>Cần khắc phục:</strong> {aiResult.improvements}
                </div>
              )}
            </div>
          </div>
        )}

        {/* MỤC: Học sinh này đạt chuẩn ở mức độ nào */}
        <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-2">
          <label className="block font-bold text-slate-900 dark:text-slate-100 text-xs flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-blue-600" />
              Mục: Học sinh này đạt chuẩn ở mức độ nào?
            </span>
            <span className="text-[11px] font-normal text-slate-500">Chuẩn năng lực Tin học GDPT 2018</span>
          </label>

          {/* Quick Level Pills */}
          <div className="flex flex-wrap gap-1.5">
            {[
              {
                lvl: 'Mức 4 (Vượt yêu cầu)',
                text: `Đạt chuẩn ở Mức 4 (Vượt yêu cầu) – Năng lực sử dụng công cụ soạn thảo và bảng biểu xuất sắc`,
                color: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300',
              },
              {
                lvl: 'Mức 3 (Đạt yêu cầu)',
                text: `Đạt chuẩn ở Mức 3 (Đạt yêu cầu) – Thao tác tạo bảng và định dạng văn bản đúng chuẩn năng lực Tin học Khối ${grade}`,
                color: 'bg-sky-100 text-sky-800 hover:bg-sky-200 dark:bg-sky-950/60 dark:text-sky-300',
              },
              {
                lvl: 'Mức 2 (Đạt một phần)',
                text: `Đạt chuẩn ở Mức 2 (Đạt một phần) – Đã tạo được sản phẩm nhưng còn thiếu sót về định dạng và dữ liệu`,
                color: 'bg-amber-100 text-amber-800 hover:bg-amber-200 dark:bg-amber-950/60 dark:text-amber-300',
              },
              {
                lvl: 'Mức 1 (Chưa đạt)',
                text: `Đạt chuẩn ở Mức 1 (Chưa đạt) – Chưa hoàn thành các thao tác cơ bản theo yêu cầu bài học`,
                color: 'bg-rose-100 text-rose-800 hover:bg-rose-200 dark:bg-rose-950/60 dark:text-rose-300',
              },
            ].map((p, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setStandardLevelText(p.text)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer border border-transparent ${p.color}`}
              >
                {p.lvl}
              </button>
            ))}
          </div>

          <input
            type="text"
            value={standardLevelText}
            onChange={(e) => setStandardLevelText(e.target.value)}
            placeholder="Nhập mức đạt chuẩn năng lực của học sinh..."
            className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs font-medium text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Criterion Selector & Level Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Chọn tiêu chí chấm ({criteria.length} tiêu chí)
            </label>
            <select
              value={activeCriterionIdx}
              onChange={(e) => setActiveCriterionIdx(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs font-medium text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              {criteria.map((c, i) => (
                <option key={i} value={i}>
                  TC{i + 1}: {c[0]} ({c[1]}%)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Mức đạt cho TC{activeCriterionIdx + 1}:
            </label>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs font-bold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500"
            >
              <option value={1}>Mức 1 – Chưa đạt</option>
              <option value={2}>Mức 2 – Đạt một phần</option>
              <option value={3}>Mức 3 – Đạt yêu cầu</option>
              <option value={4}>Mức 4 – Vượt yêu cầu</option>
            </select>
          </div>
        </div>

        {/* Rubric Descriptor Preview */}
        <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg p-3">
          <div className="font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
            <span>Mô tả chuẩn Rubric tại Mức {selectedLevel}:</span>
            <span className="text-[11px] text-blue-600 dark:text-blue-400 font-bold">
              Trọng số TC{activeCriterionIdx + 1}: {activeCriterion[1]}%
            </span>
          </div>
          <p className="text-slate-600 dark:text-slate-300 text-xs leading-relaxed italic">
            &ldquo;{activeCriterion[2][selectedLevel - 1]}&rdquo;
          </p>
        </div>

        {/* Evidence Input */}
        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
            <span>Minh chứng thực tế cho TC{activeCriterionIdx + 1} (Bắt buộc để lưu chính thức):</span>
            <span className="text-[11px] text-slate-500 font-normal">Số bảng, số hàng, số cột, chính tả...</span>
          </label>
          <textarea
            rows={2}
            value={evidenceText}
            onChange={(e) => setEvidenceText(e.target.value)}
            placeholder="Ví dụ: Bảng có đủ 4 cột và 5 hàng dữ liệu; đã định dạng chữ in đậm và căn lề đúng yêu cầu..."
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2.5 text-xs leading-relaxed focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Teacher Feedback Input */}
        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Lời nhận xét sư phạm tổng thể của giáo viên:
          </label>
          <textarea
            rows={2}
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
            placeholder="Ghi nhận xét ưu điểm và hướng dẫn cụ thể để học sinh tiến bộ..."
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2.5 text-xs leading-relaxed focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* 4-Criteria Level Badges */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
          <span className="font-semibold text-slate-600 dark:text-slate-400 text-xs">Mức 4 tiêu chí:</span>
          {criteria.map((c, i) => {
            const lvl = currentLevels[i] || 3;
            return (
              <button
                key={i}
                type="button"
                onClick={() => setActiveCriterionIdx(i)}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                  activeCriterionIdx === i
                    ? 'ring-2 ring-blue-500 bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                TC{i + 1}: Mức {lvl}
              </button>
            );
          })}
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            onClick={handleSaveDraft}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            Lưu bản nháp
          </button>

          <button
            onClick={handleConfirm}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-sm"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Xác nhận & Lưu chính thức
          </button>

          {assessment && (
            <button
              onClick={onRevokeAssessment}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              <Undo2 className="w-3.5 h-3.5" />
              Mở khóa / Hủy xác nhận
            </button>
          )}

          <div className="flex items-center gap-1 ml-auto">
            <button
              onClick={onBackupJson}
              className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Sao lưu JSON"
            >
              <Download className="w-4 h-4" />
            </button>
            <label
              className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer inline-flex"
              title="Khôi phục JSON"
            >
              <Upload className="w-4 h-4" />
              <input type="file" accept=".json" onChange={onRestoreJson} className="hidden" />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
