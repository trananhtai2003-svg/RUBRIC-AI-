import React from 'react';
import { Award, CheckCircle2, Download, Printer, FileText, Check } from 'lucide-react';
import { AssessmentRecord, Criterion } from '../types/rubric';
import { fmt } from '../utils/rubricLogic';

interface EvidenceViewProps {
  confirmedAssessments: AssessmentRecord[];
  criteria: Criterion[];
  grade: number;
  lesson: number;
  lessonTitle: string;
  onExportCsv: () => void;
  onPrint: () => void;
}

export const EvidenceView: React.FC<EvidenceViewProps> = ({
  confirmedAssessments,
  criteria,
  grade,
  lesson,
  lessonTitle,
  onExportCsv,
  onPrint,
}) => {
  return (
    <div className="space-y-4">
      {/* Evidence Overview Box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-100 dark:border-emerald-900/50 px-4 py-3 flex items-center justify-between">
          <h3 className="font-bold text-emerald-900 dark:text-emerald-200 text-sm sm:text-base flex items-center gap-1.5">
            <Award className="w-5 h-5 text-emerald-600" />
            Hồ sơ minh chứng phục vụ báo cáo Sáng kiến kinh nghiệm (SKKN)
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={onPrint}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              In minh chứng
            </button>
            <button
              onClick={onExportCsv}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Xuất CSV
            </button>
          </div>
        </div>

        <div className="p-4 space-y-3.5 text-xs">
          <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
            Hệ thống RUBRIC AI thu thập và lưu trữ đầy đủ 5 thành tố minh chứng chuẩn sư phạm phục vụ nghiệm thu SKKN đổi mới phương pháp kiểm tra đánh giá theo định hướng phát triển năng lực:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              {
                title: '1. Rubric công khai trước giờ học',
                desc: 'Bảng tiêu chí, trọng số và 4 mức độ biểu hiện giúp học sinh chủ động định hướng sản phẩm.',
              },
              {
                title: '2. Tệp sản phẩm học sinh',
                desc: 'Văn bản Word (.docx), bảng tính hoặc mã nguồn thực tế được ghép tự động theo mã học sinh.',
              },
              {
                title: '3. Phiếu chấm theo tiêu chí & mức đạt',
                desc: 'Phân tích định dạng chi tiết, tự động phát hiện số hàng/cột, bảng biểu và độ dài nội dung.',
              },
              {
                title: '4. Minh chứng cụ thể & Nhận xét của GV',
                desc: 'Giáo viên bắt buộc ghi nhận lỗi, vị trí dữ liệu và xác nhận vào hồ sơ điểm chính thức.',
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-start gap-2.5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-slate-100 text-xs">
                    {item.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 rounded-lg text-xs text-amber-800 dark:text-amber-300">
            <strong>Ghi chú chuyên môn:</strong> Tên học sinh và các phiếu mẫu trong hệ thống là dữ liệu mô phỏng thử nghiệm. Khi đưa vào hồ sơ báo cáo chính thức, thầy cô chỉ sử dụng các phiếu chấm đã được xác minh trên sản phẩm thực tế của học sinh.
          </div>
        </div>
      </div>

      {/* Confirmed Assessments Table for SKKN Report */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h4 className="font-bold text-slate-900 dark:text-slate-100 text-xs sm:text-sm">
            Danh sách phiếu chấm đã xác nhận – Khối {grade} ({lessonTitle})
          </h4>
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
            {confirmedAssessments.length} phiếu đã duyệt
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                <th className="p-2 border border-slate-200 dark:border-slate-700 text-center w-10">STT</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 w-24">Mã HS</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700">Họ và tên</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 text-center w-16">Lớp</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 text-center w-28">Mức 4 tiêu chí</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 text-center w-20">Điểm /10</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 text-center w-20">Xếp loại</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 w-48">Tệp bài làm</th>
                <th className="p-2 border border-slate-200 dark:border-slate-700 w-32 text-center">Thời điểm xác nhận</th>
              </tr>
            </thead>
            <tbody>
              {confirmedAssessments.map((a, idx) => (
                <tr
                  key={a.key}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800"
                >
                  <td className="p-2 text-center font-mono text-[11px] text-slate-500">{idx + 1}</td>
                  <td className="p-2 font-mono font-bold text-blue-700 dark:text-blue-300">{a.studentCode}</td>
                  <td className="p-2 font-bold text-slate-900 dark:text-slate-100">{a.studentName}</td>
                  <td className="p-2 text-center font-mono">{a.className}</td>
                  <td className="p-2 text-center font-mono font-semibold">
                    {a.levels.map((lvl, lIdx) => (
                      <span key={lIdx} className="mr-1">
                        T{lIdx + 1}:{lvl}
                      </span>
                    ))}
                  </td>
                  <td className="p-2 text-center font-bold font-mono text-blue-700 dark:text-blue-300">
                    {fmt(a.score)}
                  </td>
                  <td className="p-2 text-center">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                      {a.rating}
                    </span>
                  </td>
                  <td className="p-2 font-mono text-[11px] text-slate-600 dark:text-slate-400 truncate max-w-[180px]">
                    {a.sourceFile || 'Chưa gắn tệp'}
                  </td>
                  <td className="p-2 text-center text-[10px] text-slate-500 font-mono">
                    {new Date(a.confirmedAt).toLocaleDateString('vi-VN')}
                  </td>
                </tr>
              ))}

              {confirmedAssessments.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-slate-400 italic">
                    Chưa có phiếu chấm nào được xác nhận cho bài học này. Vui lòng rà soát và xác nhận tại trang &ldquo;Kết quả chấm điểm&rdquo; hoặc &ldquo;Ghép bài nộp&rdquo;.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
